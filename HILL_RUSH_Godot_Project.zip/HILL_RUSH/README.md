# HILL RUSH

Original 3D hill-driving starter game built with Godot 4.3.

## Included
- Procedurally generated rolling green terrain with collision
- A simple 3D off-road car made from primitive meshes
- Acceleration, braking/reverse, steering and gravity
- Follow camera
- Mobile on-screen gas and brake buttons
- Distance and fuel HUD

## Run in Godot
1. Install Godot 4.3 Standard (not .NET).
2. Import this folder by selecting `project.godot`.
3. Press F6/F5 or the Play button.
4. Keyboard: W/Up = accelerate, S/Down = brake/reverse, A/D = steer (steering actions can be added in Project Settings > Input Map).

## Android export
1. Install Godot 4.3 Standard on a desktop environment.
2. In Godot, open Editor > Manage Export Templates and install the matching 4.3 templates.
3. Install Android Studio / Android SDK and configure Editor Settings > Export > Android:
   - Java SDK Path
   - Android SDK Path
4. Project > Export > Add... > Android.
5. Set package name to `com.hillrush.game`, enable ARM64, and export a debug APK.

This starter project is a foundation. Add coin pickups, fuel cans, garage, upgrades, sound and more vehicles in later milestones.
