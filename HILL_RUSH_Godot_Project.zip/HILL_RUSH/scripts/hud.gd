extends CanvasLayer

var car: CharacterBody3D
var info: Label
var fuel_bar: ProgressBar

func _ready() -> void:
    await get_tree().process_frame
    car = get_parent().get_node("PlayerCar") as CharacterBody3D
    _add_controls()
    _add_info()

func _add_info() -> void:
    var panel := PanelContainer.new()
    panel.position = Vector2(18, 18)
    panel.custom_minimum_size = Vector2(270, 104)
    add_child(panel)
    var col := VBoxContainer.new()
    panel.add_child(col)
    info = Label.new()
    info.text = "HILL RUSH   |   DISTANCE 0 m"
    info.add_theme_font_size_override("font_size", 19)
    col.add_child(info)
    fuel_bar = ProgressBar.new()
    fuel_bar.max_value = 100
    fuel_bar.value = 100
    fuel_bar.custom_minimum_size = Vector2(240, 18)
    col.add_child(fuel_bar)
    var hint := Label.new()
    hint.text = "Coins: 0     W / ▲ accelerate     S / ▼ brake"
    hint.add_theme_font_size_override("font_size", 13)
    col.add_child(hint)

func _add_controls() -> void:
    _make_button("BRAKE", Vector2(24, -112), "brake")
    _make_button("GAS  ▲", Vector2(-174, -112), "accelerate")
    _make_button("◀", Vector2(-350, -112), "steer_left", Vector2(88, 82))
    _make_button("▶", Vector2(-260, -112), "steer_right", Vector2(88, 82))

func _make_button(label_text: String, offset: Vector2, action: String, button_size: Vector2 = Vector2(150, 82)) -> void:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size = button_size
    button.anchor_left = 1.0 if offset.x < 0 else 0.0
    button.anchor_right = 1.0 if offset.x < 0 else 0.0
    button.anchor_top = 1.0
    button.anchor_bottom = 1.0
    button.position = offset
    button.add_theme_font_size_override("font_size", 22)
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))
    add_child(button)

func _process(_delta: float) -> void:
    if is_instance_valid(car) and is_instance_valid(info):
        info.text = "HILL RUSH   |   DISTANCE %d m" % int(car.distance_m)
        fuel_bar.value = car.fuel
