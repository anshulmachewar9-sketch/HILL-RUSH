extends CharacterBody3D

const SPEED := 24.0
const REVERSE_SPEED := 10.0
const ACCELERATION := 20.0
const BRAKE_POWER := 28.0
const GRAVITY := 22.0

var distance_m := 0.0
var coins := 0
var fuel := 100.0
var drive_speed := 0.0
var body_mesh: MeshInstance3D
var camera: Camera3D
var wheel_nodes: Array[Node3D] = []

func _ready() -> void:
    _setup_input()
    name = "PlayerCar"
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(1.8, 0.8, 3.0)
    shape.shape = box
    shape.position.y = 0.65
    add_child(shape)
    _build_visual_car()
    _build_camera()

func _setup_input() -> void:
    var key_map := {
        "accelerate": KEY_W,
        "brake": KEY_S,
        "steer_left": KEY_A,
        "steer_right": KEY_D
    }
    for action in key_map:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
        var event := InputEventKey.new()
        event.physical_keycode = key_map[action]
        InputMap.action_add_event(action, event)

func _build_visual_car() -> void:
    body_mesh = MeshInstance3D.new()
    var box_mesh := BoxMesh.new()
    box_mesh.size = Vector3(1.9, 0.65, 3.1)
    body_mesh.mesh = box_mesh
    body_mesh.position.y = 0.8
    var paint := StandardMaterial3D.new()
    paint.albedo_color = Color(0.95, 0.22, 0.07)
    paint.metallic = 0.25
    paint.roughness = 0.35
    body_mesh.material_override = paint
    add_child(body_mesh)

    var cabin := MeshInstance3D.new()
    var cabin_mesh := BoxMesh.new()
    cabin_mesh.size = Vector3(1.35, 0.65, 1.45)
    cabin.mesh = cabin_mesh
    cabin.position = Vector3(0, 1.38, -0.15)
    var glass := StandardMaterial3D.new()
    glass.albedo_color = Color(0.12, 0.22, 0.30)
    glass.metallic = 0.4
    cabin.material_override = glass
    add_child(cabin)

    for x in [-0.98, 0.98]:
        for z in [-1.0, 1.0]:
            var wheel := MeshInstance3D.new()
            var cylinder := CylinderMesh.new()
            cylinder.top_radius = 0.43
            cylinder.bottom_radius = 0.43
            cylinder.height = 0.28
            wheel.mesh = cylinder
            wheel.rotation.z = PI / 2
            wheel.position = Vector3(x, 0.42, z)
            var rubber := StandardMaterial3D.new()
            rubber.albedo_color = Color(0.035, 0.035, 0.04)
            wheel.material_override = rubber
            add_child(wheel)
            wheel_nodes.append(wheel)

func _build_camera() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 5.0, 10.5)
    camera.rotation_degrees = Vector3(-16, 0, 0)
    camera.current = true
    camera.fov = 72
    add_child(camera)

func _physics_process(delta: float) -> void:
    var throttle := Input.get_action_strength("accelerate")
    var brake := Input.get_action_strength("brake")
    var steer := Input.get_action_strength("steer_right") - Input.get_action_strength("steer_left")

    if throttle > 0.0:
        drive_speed = move_toward(drive_speed, SPEED, ACCELERATION * delta)
    elif brake > 0.0:
        if drive_speed > 0.5:
            drive_speed = move_toward(drive_speed, 0.0, BRAKE_POWER * delta)
        else:
            drive_speed = move_toward(drive_speed, -REVERSE_SPEED, ACCELERATION * 0.6 * delta)
    else:
        drive_speed = move_toward(drive_speed, 0.0, 3.0 * delta)

    velocity.z = -drive_speed
    velocity.x = steer * min(abs(drive_speed) * 0.12, 3.0)
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    else:
        velocity.y = -0.2

    move_and_slide()
    distance_m = max(distance_m, -global_position.z)
    fuel = max(0.0, fuel - abs(drive_speed) * delta * 0.012)
    rotation.z = lerp_angle(rotation.z, -steer * 0.10, delta * 3.0)

    for wheel in wheel_nodes:
        wheel.rotate_x(drive_speed * delta * 0.8)

    camera.position = camera.position.lerp(Vector3(0, 5.0, 10.5), delta * 2.0)
    camera.look_at(global_position + Vector3(0, 1.0, -5.0), Vector3.UP)
