extends Node3D

const CAR_SCRIPT = preload("res://scripts/car.gd")
const HUD_SCRIPT = preload("res://scripts/hud.gd")

func _ready() -> void:
    _make_environment()
    _make_terrain()
    var car := CharacterBody3D.new()
    car.name = "PlayerCar"
    car.set_script(CAR_SCRIPT)
    car.position = Vector3(0, 5, 0)
    add_child(car)

    var hud := CanvasLayer.new()
    hud.name = "HUD"
    hud.set_script(HUD_SCRIPT)
    add_child(hud)

func _make_environment() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.sky.sky_material = ProceduralSkyMaterial.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.82, 0.95)
    env.ambient_light_energy = 0.8
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -35, 0)
    sun.light_energy = 1.2
    add_child(sun)

func _height(x: float, z: float) -> float:
    return 1.2 * sin(z * 0.045) + 0.55 * sin(z * 0.11 + x * 0.025) + 0.25 * sin(x * 0.06)

func _make_terrain() -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var width := 180.0
    var depth := 650.0
    var step := 5.0
    var nx := int(width / step)
    var nz := int(depth / step)
    for zi in range(nz):
        for xi in range(nx):
            var x0 := -width / 2.0 + xi * step
            var x1 := x0 + step
            var z0 := -depth / 2.0 + zi * step
            var z1 := z0 + step
            var a := Vector3(x0, _height(x0, z0), z0)
            var b := Vector3(x1, _height(x1, z0), z0)
            var c := Vector3(x1, _height(x1, z1), z1)
            var d := Vector3(x0, _height(x0, z1), z1)
            st.add_vertex(a); st.add_vertex(c); st.add_vertex(b)
            st.add_vertex(a); st.add_vertex(d); st.add_vertex(c)
    st.generate_normals()
    var mesh := st.commit()
    var terrain := MeshInstance3D.new()
    terrain.name = "RollingHills"
    terrain.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.24, 0.55, 0.22)
    mat.roughness = 1.0
    terrain.material_override = mat
    add_child(terrain)

    var body := StaticBody3D.new()
    body.name = "TerrainCollision"
    var collision := CollisionShape3D.new()
    collision.shape = mesh.create_trimesh_shape()
    body.add_child(collision)
    add_child(body)

    # Simple distant scenery
    for i in range(14):
        var hill := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        sphere.radius = 18.0 + float(i % 4) * 4.0
        sphere.height = sphere.radius * 1.5
        hill.mesh = sphere
        var m := StandardMaterial3D.new()
        m.albedo_color = Color(0.20, 0.43, 0.25)
        hill.material_override = m
        hill.position = Vector3(-100.0 if i % 2 == 0 else 100.0, -4.0, -220.0 - i * 32.0)
        add_child(hill)
